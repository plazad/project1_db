/* Creating the following tables in the database:
 *--MOVIE(TITLE,DIR,YEAR,BUDGET,LANGUAGE)
 *--CAST(TITLE,ACTOR)
 *--REVIEW(CRITIC,TITLE,SCORE)
 *
 * */

import java.sql.*;

public class  p1{

        public static void main(String args[]) throws java.sql.SQLException, java.io.IOException{
                try{
                        Class.forName("oracle.jdbc.driver.OracleDriver");
                }
                catch (ClassNotFoundException e){
                        System.out.println("Could not load oracle driver");
                        System.exit(-1);
                }
                String usr="";
                String pwd="";

                /* Conecting to oracle*/
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+usr+"/"+pwd+"@aos.acsu.buffalo.edu:1521/aos.buffalo.edu");
                System.out.println("URL = "+con.getMetaData().getURL());
                System.out.println("Username = "+con.getMetaData().getUserName());

                Statement st = con.createStatement();//allows you to insert sql statements


                /* delete tables if they already exist*/
                System.out.println("Dropping tables movie, cast and review if they exist...");
                String drop = "BEGIN EXECUTE IMMEDIATE 'DROP TABLE movie'; EXCEPTION WHEN OTHERS THEN NULL; END;";
                st.executeUpdate(drop);

                drop = "BEGIN EXECUTE IMMEDIATE 'DROP TABLE \"cast\"'; EXCEPTION WHEN OTHERS THEN NULL; END;";
                st.executeUpdate(drop);

                drop = "BEGIN EXECUTE IMMEDIATE 'DROP TABLE review'; EXCEPTION WHEN OTHERS THEN NULL; END;";
                st.executeUpdate(drop);

                /*create schema for tables*/
                System.out.println("Creating schema for tables movie, cast and review...");
                String ct = "create table movie (title varchar(255) primary key, dir varchar(255), \"year\" int, budget number, \"language\" varchar(255))";
                st.execute(ct);

                ct = "create table \"cast\" (title varchar(255), actor varchar(255), primary key (title, actor))";
                st.execute(ct);
                
				ct = "create table review (critic varchar(255), title varchar(255), score number, primary key (critic, title))";
                st.execute(ct);

                /*insert data into movie table*/
                System.out.println("\ninserting data into table MOVIE...");
                String in = "insert into movie values ('Jaws', 'Spielberg', 1975, 2.5, 'English')";//executeUpdate
                st.executeUpdate(in);

                in = "insert into movie values ('Saving Private Ryan', 'Spielberg', 1998, 7.5, 'English')";
                st.executeUpdate(in);

                in = "insert into movie values ('E.T. the Extra-Terrestrial', 'Spielberg', 1982, 0.5, 'English')";
                st.executeUpdate(in);

                in = "insert into movie values ('Minority Report', 'Spielberg', 2002, 6.5, 'English')";
                st.executeUpdate(in);

                in = "insert into movie values ('Munich', 'Spielberg', 2002, 6.5, 'French')";
                st.executeUpdate(in);

                in = "insert into movie values ('Amelie', 'Jean-Pierre Jeunet', 2001, 1.0, 'French')";
                st.executeUpdate(in);

                in = "insert into movie values ('The Intouchables', 'Olivier Nakache', 2011, 1.0, 'French')";
                st.executeUpdate(in);

                in = "insert into movie values ('Arrival', 'Denis Villeneuve', 2016, 7, 'English')";
                st.executeUpdate(in);

                in = "insert into movie values ('The Terminal', 'Spielberg', 2004, 1, 'English')";
                st.executeUpdate(in);

                /* Outputting every movie in the table movie*/
                System.out.println("Loading content stored in MOVIE to display...");
                String sq = "Select * from movie";
                ResultSet rs;
                rs = st.executeQuery(sq); //what is returned is stored
                System.out.printf("%n %n **************************************%n");
                System.out.println("\t\t MOVIE ");
                System.out.printf("%n **************************************%n");
                
                /*Inserting data into cast table*/
                System.out.println("\n\nInserting data into \"cast\" table...");
                in = "insert into \"cast\" values ('Jaws', 'Roy Scheider')";
                st.executeUpdate(in);

                in = "insert into \"cast\" values ('Saving Private Ryan', 'Tom Hanks')";
                st.executeUpdate(in);

                in = "insert into \"cast\" values ('E.T. the Extra-Terrestrial', 'Henry Thomas')";
                st.executeUpdate(in);

                in = "insert into \"cast\" values ('Minority Report', 'Tom Cruise')";
                st.executeUpdate(in);

                in = "insert into \"cast\" values ('Munich', 'Eric Bana')";
                st.executeUpdate(in);

                in = "insert into \"cast\" values ('Amelie', 'Audrey Tautou')";
                st.executeUpdate(in);

                in = "insert into \"cast\" values ('The Intouchables', 'Francois Cluzet')";
                st.executeUpdate(in);

                in = "insert into \"cast\" values ('Arrival', 'Jeremy Renner')";
                st.executeUpdate(in);

                in = "insert into \"cast\" values ('The Terminal', 'Tom Hanks')";
                st.executeUpdate(in);

                /* Outputting data in the table cast */
                System.out.println("Loading content stored in \"CAST\" to display...");
                sq = "Select * from \"cast\"";
                rs = st.executeQuery(sq);
                System.out.printf("%n %n **************************************%n");
                System.out.println("\t\t \"CAST\" ");
                System.out.printf("%n **************************************%n");
                print(rs); //calls 'print' 


				/* Inserting data into review tables table*/
                System.out.println("\n\nInserting values to review table...");
                in = "\ninsert into review values ('Manny Farber', 'Jaws', 8.1)";
                st.executeUpdate(in);

                in = "insert into review values ('Manny Farber', 'Saving Private Ryan', 9.1)";
                st.executeUpdate(in);

                in = "insert into review values ('Vincent Canby', 'E.T. the Extra-Terrestrial', 7.0)";
                st.executeUpdate(in);

                in = "insert into review values ('Todd McCarthy', 'Minority Report', 7.6)";
                st.executeUpdate(in);

                in = "insert into review values ('A.O. Scott', 'Munich', 8.7)";
                st.executeUpdate(in);

                in = "insert into review values ('Jonathan Rosenbaum', 'Amelie', 8.7)";
                st.executeUpdate(in);

                in = "insert into review values ('Manohla Dargis', 'The Intouchables', 7.5)";
                st.executeUpdate(in);

                in = "insert into review values ('Manohla Dargis', 'Arrival', 8)";
                st.executeUpdate(in);

                in = "insert into review values ('David Denby', 'The Terminal', 7.9)";
                st.executeUpdate(in);

                in = "insert into review values ('David Denby', 'Jaws', 8.3)";
                st.executeUpdate(in);

                in = "insert into review values ('Jonathan Rosenbaum','Saving Private Ryan', 9)";
                st.executeUpdate(in);

                in = "insert into review values ('Todd McCarthy', 'E.T. the Extra-Terrestrial', 7.9)";
                st.executeUpdate(in);

                in = "insert into review values ('A.O. Scott', 'Minority Report', 7.3)";
                st.executeUpdate(in);

                in = "insert into review values ('Manny Farber', 'Munich', 8.3)";
                st.executeUpdate(in);


				/* Outputting data from the table review*/
                System.out.println("Loading content stored in REVIEW to display...");
                sq = "Select * from review";
                rs = st.executeQuery(sq); //what is returned is stored
                System.out.printf("%n %n **************************************%n");
                System.out.println("\t\t REVIEW ");
                System.out.printf("%n **************************************%n");
                print(rs); //calls 'print' 

                System.out.println("\n\nNow performing query: \n \t Select critic, AVG(score) from review GROUP BY critic; \n ");
                System.out.println("\n\n***************************************");
                System.out.println("\t CRITICS AVG SCORE");
                System.out.println("\n\n***************************************\n");

                sq = "Select critic, avg(score) from review group by critic";
                rs = st.executeQuery(sq);
                print(rs);

                System.out.println("FINISHED \n");

        }//end of p1

        public static void print(ResultSet rs) throws java.sql.SQLException{
                String s = "";
                while (rs.next()){
                        int cl = rs.getMetaData().getColumnCount();
                        for(int i=1; i<= cl; ++i){ s += rs.getString(i) + "\t";} //take string at first location, then is appended
                        System.out.println(s);
                        s = "";
                }//end of while

        }//end of print



};//end of Class
                                        